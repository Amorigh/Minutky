#include "stm8s.h"

#define SEG1 (GPIO_PIN_1)
#define SEG2 (GPIO_PIN_2)
#define SEG3 (GPIO_PIN_3)
#define SEG4 (GPIO_PIN_4)

// Tlačítka
#define BUTTON1 (GPIO_PIN_1)
#define BUTTON2 (GPIO_PIN_2)
#define BUTTON3 (GPIO_PIN_3)
#define BUTTON4 (GPIO_PIN_4)
#define BUTTON5 (GPIO_PIN_6)
#define BUTTON6 (GPIO_PIN_7)

#define SEGOFF(SEG) (GPIO_WriteHigh(GPIOG, SEG))
#define SEGON(SEG) (GPIO_WriteLow(GPIOG, SEG))

#define buttonPressed(BUTTON) (GPIO_ReadInputPin(GPIOC, BUTTON)==RESET)


#define len(arr) sizeof(arr)/sizeof(arr[0])

// Funkce
void spozdeni(uint32_t iterations);
void zmenacasu();
void zmenastavu();
void reset();
void bzuceni(int timeUnit);


uint8_t stav= 0; 
uint8_t segValues[4] = {0, 0, 0, 0}; 
GPIO_Pin_TypeDef segButtons[4] = {BUTTON1, BUTTON2, BUTTON3, BUTTON4}; 
int sekundy; 
int minuty; 
uint16_t citacbzuceni = 0; 

// Přerušení
INTERRUPT_HANDLER(EXTI_PORTC_IRQHandler, 5)
{
    if (stav == 0) {zmenacasu();} 
    if (buttonPressed(BUTTON5)) {zmenastavu();} 
    
    if (buttonPressed(BUTTON6)) {reset();} 
}

void main(void)
{
    
    GPIO_DeInit;
    TIM4_DeInit;
    EXTI_DeInit;

    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1); 

    // Inicializace potřebných portů na STM8
    GPIO_Init(GPIOC, GPIO_PIN_ALL, GPIO_MODE_IN_PU_IT);
    GPIO_Init(GPIOG, GPIO_PIN_ALL, GPIO_MODE_OUT_PP_LOW_SLOW);
    GPIO_Init(GPIOD, GPIO_PIN_6, GPIO_MODE_OUT_PP_LOW_SLOW);
    GPIO_Init(GPIOB, GPIO_PIN_ALL, GPIO_MODE_OUT_PP_LOW_SLOW);

    
    EXTI_SetExtIntSensitivity(EXTI_PORT_GPIOC, EXTI_SENSITIVITY_FALL_ONLY);
    ITC_SetSoftwarePriority(ITC_IRQ_PORTC, ITC_PRIORITYLEVEL_0);
    enableInterrupts();

    
    TIM4_TimeBaseInit(TIM4_PRESCALER_128, 250);
    TIM4_Cmd(ENABLE);

    
    GPIO_Pin_TypeDef SEGS[8] = {SEG1, SEG2, SEG3, SEG4}; // 7segmenty
    uint8_t nums[10] = {0b00111111, 0b00000110, 0b01011011, 
                    0b01001111, 0b01100110, 0b01101101, 
                    0b01111101, 0b00000111, 0b01111111, 
                    0b01100111}; // Čísla zobrazované na 4dig 7segmentu
    uint32_t timeUnit = 0; 

    // Výpočet sekund a minut z čísel na 4dig 7segmentu
    sekundy = segValues[2] * 10 + segValues[3];
    minuty = segValues[0] * 10 + segValues[1];

    while (1)
    {
        
        if (stav == 1) {

            
            uint8_t segSum = 0; 
            for(uint8_t i = 0; i < len(segValues); i++) {
                segSum += segValues[i];
            }

            if(TIM4_GetFlagStatus(TIM4_FLAG_UPDATE)==SET) {
                TIM4_ClearFlag(TIM4_FLAG_UPDATE);
                timeUnit++;

                
                if (segSum == 0) {
                    if (timeUnit == 500) {
                        timeUnit = 0;
                        citacbzuceni++;
                    }
                    bzuceni(timeUnit);
                }
            }
            
            if (segSum != 0) {
                
                if (timeUnit == 500) {
                    timeUnit = 0;
                    sekundy--;
                }

                
                if (sekundy<0) {
                    sekundy = 59;
                    if (minuty != 0) {
                        minuty--;
                    }
                }

               
                segValues[3] = sekundy % 10;
                segValues[2] = sekundy / 10;
                segValues[1] = minuty % 10;
                segValues[0] = minuty / 10;
            }
        } 
        
        // Zobrazení číselných hodnot na 4dig 7segmentu
        for (uint8_t i = 0; i < len(SEGS); i++) {
            SEGON(SEGS[i]);
            GPIO_Write(GPIOB, nums[segValues[i]]);
            if (i == 1) {GPIO_WriteHigh(GPIOB, GPIO_PIN_7);} 
            spozdeni(150);
            SEGOFF(SEGS[i]);
        }
    }
}


void spozdeni(uint32_t iter)
{
    for(uint32_t i = 0; i < iter; i++);
}

// Změna číselných hodnot, které se mají odpočítávat
void zmenacasu() {
    for (uint8_t i = 0; i < len(segButtons); i++) {
        if (buttonPressed(segButtons[i])) {
            
            segValues[i]++;
            if (i == 2) { 
                if (segValues[i] > 5) {
                    segValues[i] = 0;
                }
            } else { 
                if (segValues[i] > 9) {
                    segValues[i] = 0;
                }
            }
        }
        
        minuty = segValues[0] * 10 + segValues[1];
        sekundy = segValues[2] * 10 + segValues[3];
    }
}


void zmenastavu() {
    if (stav == 0) {
        stav = 1;
        citacbzuceni = 0;
    } else {
        stav = 0;
    }
}


void reset() {
    stav = 0;
    GPIO_WriteLow(GPIOD, GPIO_PIN_6); 

    
    for (uint8_t i = 0; i < len(segValues); i++) {
        segValues[i] = 0;
    }
    minuty = segValues[0] * 10 + segValues[1];
    sekundy = segValues[2] * 10 + segValues[3];
}


void bzuceni(int timeUnit) {
    if (citacbzuceni < 10) {
        
        if (timeUnit == 100) {
            GPIO_WriteHigh(GPIOD, GPIO_PIN_6);
        }
    
    } else if (citacbzuceni == 10) {
        GPIO_WriteLow(GPIOD, GPIO_PIN_6);
        stav = 0;
    }
}
